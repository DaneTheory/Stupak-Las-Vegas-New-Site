more tutorial and web development resource ?
check http://freshwebdev.com