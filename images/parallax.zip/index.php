<html>
<head>
 <link href="style.css" rel="stylesheet">
 <script src="parallax.js"></script>
</head>
<body>
<div id="scroll-animate">
  <div id="scroll-animate-main">
    <div class="wrapper-parallax">
      <header>
        <h1>Header</h1>
      </header>

      <section class="content">
        <h1>Content</h1>
      </section>

      <footer>
        <h1>Footer</h1>
      </footer>
    </div>
  </div>
</div>
</body>
</html>